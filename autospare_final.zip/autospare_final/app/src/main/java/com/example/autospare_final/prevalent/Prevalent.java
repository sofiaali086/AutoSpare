package com.example.autospare_final.prevalent;

import com.example.autospare_final.entities.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public static final String UserPhoneKey="UserPhone";
    public static final String UserPasswordKey="UserPassword";
}
