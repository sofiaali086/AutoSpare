package com.example.autospare_final.ViewHolder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.autospare_final.Interface.ItemClickListner;
import com.example.autospare_final.R;

public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView txtProductName, txtProductDescription,txtProductPrice;
    public ImageView imageview;
    public ItemClickListner listner;

    public ProductViewHolder(@NonNull View itemView) {
        super(itemView);

        imageview=itemView.findViewById(R.id.ivProduct_image);
        txtProductName=itemView.findViewById(R.id.tvProduct_name);
        txtProductDescription=itemView.findViewById(R.id.tvProduct_description);
        txtProductPrice=itemView.findViewById(R.id.tvProduct_price);
    }

    public void setItemClickListner(ItemClickListner listner){
        this.listner=listner;
    }

    @Override
    public void onClick(View v) {

        listner.onClick(v,getAdapterPosition(),false);
    }
}
