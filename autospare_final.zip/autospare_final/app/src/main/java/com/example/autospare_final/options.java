package com.example.autospare_final;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class options extends AppCompatActivity {

    Button options_add_product,options_update_product,options_remove_product,options_back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        options_add_product=findViewById(R.id.options_add_product);
        options_remove_product=findViewById(R.id.options_remove_product);
        options_update_product=findViewById(R.id.options_update_product);
        options_back=findViewById(R.id.options_back);

        options_add_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(options.this,add_product.class);
                startActivity(intent);
            }
        });

        options_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(options.this,admin.class);
                startActivity(intent);
            }
        });

        options_update_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(options.this,update_product.class);
                startActivity(intent);
            }
        });

        options_remove_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(options.this,remove_product.class);
                startActivity(intent);
            }
        });
    }
}
