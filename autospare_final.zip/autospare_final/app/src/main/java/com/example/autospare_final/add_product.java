package com.example.autospare_final;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class add_product extends AppCompatActivity {

    EditText product_name,product_description,product_price;
    Button add_new_product, add_product_back;
    ImageView select_product_image;
    String description,price,pname,saveCurrentDate,saveCurrentTime,productKey,downloadImageURL;

    static final int GalleryPick=1;

    Uri imageUri;
    StorageReference productImagesRef;

    DatabaseReference productRef;

    ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        productImagesRef= FirebaseStorage.getInstance().getReference().child("Product Images");
        productRef=FirebaseDatabase.getInstance().getReference().child("Products");

        product_name=findViewById(R.id.product_name);
        product_description=findViewById(R.id.product_description);
        product_price=findViewById(R.id.product_price);
        add_new_product=findViewById(R.id.add_new_product);
        add_product_back=findViewById(R.id.add_product_back);
        select_product_image=findViewById(R.id.select_product_image);

        loadingBar=new ProgressDialog(this);

        select_product_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        add_new_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateProductData();
            }
        });

        add_product_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(add_product.this,options.class);
                startActivity(intent);
            }
        });

    }

    private void validateProductData() {
        description=product_description.getText().toString();
        price=product_price.getText().toString();
        pname=product_name.getText().toString();

        if(imageUri == null){
            Toast.makeText(this, "Product image is mandatory !", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(description)){
            Toast.makeText(this, "Please write product description ..", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(price)){
            Toast.makeText(this, "Please write product price ..", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(pname)){
            Toast.makeText(this, "Please write product name ..", Toast.LENGTH_SHORT).show();
        }else{
            storeProductInformation();
        }
    }

    private void storeProductInformation() {

        loadingBar.setTitle("Adding new product..");
        loadingBar.setMessage("Please wait, while we are adding the product");
        loadingBar.setCanceledOnTouchOutside(false);
        loadingBar.show();

        Calendar calendar=Calendar.getInstance();

        SimpleDateFormat currentDate=new SimpleDateFormat("MM DD, yyyy");
        saveCurrentDate=currentDate.format(calendar.getTime());

        SimpleDateFormat currentTime=new SimpleDateFormat("HH:mm:ss a");
        saveCurrentTime=currentTime.format(calendar.getTime());

        productKey=saveCurrentDate+saveCurrentTime;


        final StorageReference filepath=productImagesRef.child(imageUri.getLastPathSegment()+ productKey+".jpg");

        final UploadTask uploadTask=filepath.putFile(imageUri);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                String message=e.toString();
                Toast.makeText(add_product.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                loadingBar.dismiss();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(add_product.this, "Image uploaded successfully !!", Toast.LENGTH_SHORT).show();

                Task<Uri> urlTask=uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if(!task.isSuccessful()){
                            throw task.getException();
                        }

                        downloadImageURL=filepath.getDownloadUrl().toString();

                        return filepath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                       if(task.isSuccessful()){
                           downloadImageURL=task.getResult().toString();

                           Toast.makeText(add_product.this, "Got Product image url successfully ...", Toast.LENGTH_SHORT).show();

                           saveProductInfoToDatabase();
                       }
                    }
                });
            }
        });
    }

    private void saveProductInfoToDatabase() {
        HashMap<String, Object> productMap=new HashMap<>();
        productMap.put("pid",productKey);
        productMap.put("date",saveCurrentDate);
        productMap.put("time",saveCurrentTime);
        productMap.put("description",description);
        productMap.put("image",downloadImageURL);
        productMap.put("price",price);
        productMap.put("pname",pname);

        productRef.child(productKey).updateChildren(productMap)
        .addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){

                    Intent intent =new Intent(add_product.this,options.class);
                    startActivity(intent);

                    loadingBar.dismiss();
                    Toast.makeText(add_product.this, "Product is added successfully.. ", Toast.LENGTH_SHORT).show();
                }else{
                    loadingBar.dismiss();
                    String message=task.getException().toString();
                    Toast.makeText(add_product.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void openGallery() {
        Intent galleryIntent=new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,GalleryPick);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==GalleryPick && resultCode==RESULT_OK && data!=null){
            imageUri=data.getData();
            select_product_image.setImageURI(imageUri);
        }

    }
}
