package com.example.autospare_final;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class register extends AppCompatActivity {

    Button registerButton;
    EditText firstName,lastName,phone,password,confirmPassword;
    ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        registerButton=findViewById(R.id.registerButton);
        firstName=findViewById(R.id.etFirstName);
        lastName=findViewById(R.id.etLastName);
        phone=findViewById(R.id.etPhone);
        password=findViewById(R.id.etRegisterPassword);
        confirmPassword=findViewById(R.id.etRegisterConfirmPassword);

        loadingBar=new ProgressDialog(this);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

    }

    private void registerUser(){

        String fn=firstName.getText().toString();
        String ln=lastName.getText().toString();
        String ph=phone.getText().toString();
        String pass=password.getText().toString();
        String c_pass=confirmPassword.getText().toString();

        if(fn.isEmpty()){
            Toast.makeText(this, "Enter First Name", Toast.LENGTH_SHORT).show();
        }else if(ln.isEmpty()){
            Toast.makeText(this, "Enter Last Name", Toast.LENGTH_SHORT).show();
        }else if(ph.isEmpty()){
            Toast.makeText(this, "Enter phone number", Toast.LENGTH_SHORT).show();
        }else if(pass.isEmpty()){
            Toast.makeText(this, "Enter Password !", Toast.LENGTH_SHORT).show();
        }else if(c_pass.isEmpty()){
            Toast.makeText(this, "Enter same password another time !", Toast.LENGTH_SHORT).show();
        }else if( !( pass.equals(c_pass) ) ) {
            Toast.makeText(this, "Password mismatch!", Toast.LENGTH_SHORT).show();
        }else{
            loadingBar.setTitle("Registering..");
            loadingBar.setMessage("Please wait, while we are checking the credentials.");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();

            validateEmailId(fn,ln,ph,pass);
        }

    }

    private void validateEmailId(final String fn, final String ln, final String ph, final String pass) {
        final DatabaseReference rootRef;
        rootRef= FirebaseDatabase.getInstance().getReference();

        rootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!(dataSnapshot.child("Users").child(ph).exists())){

                    HashMap<String, Object> userdataMap= new HashMap<>();
                    userdataMap.put("phone",ph);
                    userdataMap.put("firstname",fn);
                    userdataMap.put("lastname",ln);
                    userdataMap.put("password",pass);

                    rootRef.child("Users").child(ph).updateChildren(userdataMap)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(register.this, "Account Created !", Toast.LENGTH_SHORT).show();
                                        loadingBar.dismiss();

                                        Intent intent =new Intent(register.this,Login.class);
                                        startActivity(intent);
                                    }else{
                                        loadingBar.dismiss();
                                        Toast.makeText(register.this, "Network Failure! Try again !", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                }else{
                    Toast.makeText(register.this, "This "+ph+" already exits !", Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                    Toast.makeText(register.this, "Trying another phone number!", Toast.LENGTH_SHORT).show();

                    Intent intent =new Intent(register.this,MainActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
