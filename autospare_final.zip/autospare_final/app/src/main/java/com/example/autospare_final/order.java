package com.example.autospare_final;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.autospare_final.entities.Orders;
import com.example.autospare_final.entities.Products;
import com.example.autospare_final.prevalent.Prevalent;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class order extends AppCompatActivity {

    Button show_all_products_btn;
    TextView order_user_name,order_phone_no,order_total_price,order_address,order_date_time;
    String productId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        show_all_products_btn=findViewById(R.id.show_all_products_btn);
        order_phone_no=findViewById(R.id.order_phone_no);
        order_user_name=findViewById(R.id.order_user_name);
        order_total_price=findViewById(R.id.order_total_price);
        order_address=findViewById(R.id.order_address_city);
        order_date_time=findViewById(R.id.order_date_time);

        show_all_products_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(order.this,product_details.class);
                intent.putExtra("pid",productId);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        DatabaseReference orderRef= FirebaseDatabase.getInstance().getReference().child("Orders");

        FirebaseRecyclerOptions<Orders> optn=new FirebaseRecyclerOptions.Builder<Orders>()
                .setQuery(orderRef.child("User View")
                .child(Prevalent.currentOnlineUser.getPhone()).child("Products"),Orders.class).build();

    }
}
