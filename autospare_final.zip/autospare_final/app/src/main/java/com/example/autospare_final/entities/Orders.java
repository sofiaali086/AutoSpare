package com.example.autospare_final.entities;

public class Orders {

    String pid,pname,price;

    public Orders() {
    }

    public Orders(String pid, String pname, String price) {
        this.pid = pid;
        this.pname = pname;
        this.price = price;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
