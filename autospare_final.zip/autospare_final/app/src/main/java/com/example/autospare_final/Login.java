package com.example.autospare_final;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.autospare_final.entities.Users;
import com.example.autospare_final.prevalent.Prevalent;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import io.paperdb.Paper;

public class Login extends AppCompatActivity {

    EditText etLoginPhone,etPassword;
    Button loginButton;
    ProgressDialog loadingBar;
    TextView admin_panel_link,not_admin_panel_link;

    String parentDbName="Users";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etLoginPhone=findViewById(R.id.etLoginPhone);
        etPassword=findViewById(R.id.etPassword);
        loginButton=findViewById(R.id.loginButton);
        admin_panel_link=findViewById(R.id.admin_panel_link);
        not_admin_panel_link=findViewById(R.id.not_admin_panel_link);

        loadingBar=new ProgressDialog(this);

        Paper.init(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        admin_panel_link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginButton.setText("Login Admin");
                admin_panel_link.setVisibility(View.INVISIBLE);
                not_admin_panel_link.setVisibility(View.VISIBLE);
                parentDbName="Admins";
            }
        });

        not_admin_panel_link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginButton.setText("Login");
                admin_panel_link.setVisibility(View.VISIBLE);
                not_admin_panel_link.setVisibility(View.INVISIBLE);
                parentDbName="Users";
            }
        });
    }

    private void loginUser() {
        String ph=etLoginPhone.getText().toString();
        String pass=etPassword.getText().toString();

        if(ph.isEmpty()){
            Toast.makeText(this, "Enter phone number !", Toast.LENGTH_SHORT).show();
        }else if(pass.isEmpty()){
            Toast.makeText(this, "Enter Password !", Toast.LENGTH_SHORT).show();
        }else{
            loadingBar.setTitle("Logging..");
            loadingBar.setMessage("Please wait, while we are checking the credentials.");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();

            accessAccount(ph,pass);
        }
    }

    private void accessAccount(final String ph, final String pass) {

        Paper.book().write(Prevalent.UserPhoneKey, ph);
        Paper.book().write(Prevalent.UserPasswordKey, pass);

        final DatabaseReference rootRef;
        rootRef= FirebaseDatabase.getInstance().getReference();

        rootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child(parentDbName).child(ph).exists()){
                    Users userData=dataSnapshot.child(parentDbName).child(ph).getValue(Users.class);

                    if(userData.getPhone().equals(ph)){
                        if(userData.getPassword().equals(pass)){

                            if(parentDbName.equals("Admins")){
                                Toast.makeText(Login.this, "Welcome Admin, you are logged in successfully!", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();

                                Intent intent =new Intent(Login.this,admin.class);
                                startActivity(intent);
                            }else if(parentDbName.equals("Users")){
                                Toast.makeText(Login.this, "Logged in successfully!", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();

                                Prevalent.currentOnlineUser=userData;

                                Intent intent =new Intent(Login.this,home.class);
                                startActivity(intent);
                            }

                        }
                    }

                }else{
                    Toast.makeText(Login.this, "Account "+ph+"doesn't exist !!", Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
