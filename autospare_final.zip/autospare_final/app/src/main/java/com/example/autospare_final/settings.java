package com.example.autospare_final;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.autospare_final.prevalent.Prevalent;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class settings extends AppCompatActivity {

    CircleImageView profileImageView;
    EditText firstNameEditText,lastNameEditText, userphoneEditText,addressEditText;
    TextView profileChangeTextBtn,closeTextBtn,saveTextButton;

    Uri imageUri;
    String myUrl="";
    StorageTask uploadTask;
    StorageReference storageProfilePictureRef;
    String checker="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        storageProfilePictureRef= FirebaseStorage.getInstance().getReference().child("Profile Pictures");

        profileImageView=findViewById(R.id.settings_profile_image);
        firstNameEditText=findViewById(R.id.settings_first_name);
        lastNameEditText=findViewById(R.id.settings_last_name);
        userphoneEditText=findViewById(R.id.settings_phone_number);
        addressEditText=findViewById(R.id.settings_address);
        profileChangeTextBtn=findViewById(R.id.profile_image_change_btn);
        closeTextBtn=findViewById(R.id.close_settings);
        saveTextButton=findViewById(R.id.update_account_settings);

        userInfoDisplay(profileImageView,firstNameEditText,lastNameEditText,userphoneEditText,addressEditText);

        closeTextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        saveTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checker.equals("clicked")){
                    userInfoSaved();
                }else{
                    updateOnlyUserInfo();
                }
            }
        });

        profileChangeTextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checker="clicked";

                CropImage.activity(imageUri)
                        .setAspectRatio(1,1)
                        .start(settings.this);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode== RESULT_OK && data!=null){
            CropImage.ActivityResult result=CropImage.getActivityResult(data);
            imageUri=result.getUri();

            profileImageView.setImageURI(imageUri);
        }else{
            Toast.makeText(this, "Error , try again !", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(settings.this,settings.class));
            finish();
        }
    }

    private void updateOnlyUserInfo() {

        DatabaseReference ref=FirebaseDatabase.getInstance().getReference().child("Users");

        HashMap<String, Object> userMap= new HashMap<>();
        userMap.put("firstname",firstNameEditText.getText().toString());
        userMap.put("lastname",lastNameEditText.getText().toString());
        userMap.put("address",addressEditText.getText().toString());
        userMap.put("phoneOrder",userphoneEditText.getText().toString());
        ref.child(Prevalent.currentOnlineUser.getPhone()).updateChildren(userMap);

        startActivity(new Intent(settings.this,home.class));
        Toast.makeText(settings.this, "Update Successful !!", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void userInfoSaved(){

        if(TextUtils.isEmpty(firstNameEditText.getText().toString())){
            Toast.makeText(this, "First Name is mandatory", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(lastNameEditText.getText().toString())){
            Toast.makeText(this, "Last Name is mandatory", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(userphoneEditText.getText().toString())){
            Toast.makeText(this, "Phone number  is mandatory", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(addressEditText.getText().toString())){
            Toast.makeText(this, "Address is mandatory", Toast.LENGTH_SHORT).show();
        }else if(checker.equals("clicked")){
            uploadImage();
        }
    }

    private void uploadImage() {
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setTitle("Update Profile");
        progressDialog.setMessage("Please Wait, while we are updating your account");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        if(imageUri != null){
            final StorageReference fileRef=storageProfilePictureRef.child(Prevalent.currentOnlineUser.getPhone() + ".jpg");

            uploadTask=fileRef.putFile(imageUri);

            uploadTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {

                   if(!task.isSuccessful()){
                       throw task.getException();
                   }

                    return fileRef.getDownloadUrl();
                }
            })
                    .addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if(task.isSuccessful()){
                                Uri downloadUrl=task.getResult();
                                myUrl=downloadUrl.toString();

                                DatabaseReference ref=FirebaseDatabase.getInstance().getReference().child("Users");

                                HashMap<String, Object> userMap= new HashMap<>();
                                userMap.put("firstname",firstNameEditText.getText().toString());
                                userMap.put("lastname",lastNameEditText.getText().toString());
                                userMap.put("address",addressEditText.getText().toString());
                                userMap.put("phoneOrder",userphoneEditText.getText().toString());
                                userMap.put("image",myUrl);

                                ref.child(Prevalent.currentOnlineUser.getPhone()).updateChildren(userMap);

                                progressDialog.dismiss();

                                startActivity(new Intent(settings.this,home.class));
                                Toast.makeText(settings.this, "Update Successful !!", Toast.LENGTH_SHORT).show();
                                finish();
                            }else{
                                progressDialog.dismiss();
                                Toast.makeText(settings.this, "Error.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }else {
            Toast.makeText(this, "Image is not selected !!", Toast.LENGTH_SHORT).show();
        }
    }

    private void userInfoDisplay(final CircleImageView profileImageView, final EditText firstNameEditText, final EditText lastNameEditText, final EditText userphoneEditText, final EditText addressEditText) {

        DatabaseReference usersRef= FirebaseDatabase.getInstance().getReference().child("Users").child(Prevalent.currentOnlineUser.getPhone());

        usersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
              if(dataSnapshot.exists()){
                  if(dataSnapshot.child("image").exists()){
                      String image=dataSnapshot.child("image").getValue().toString();
                      String phone=dataSnapshot.child("phone").getValue().toString();
                      String firstname=dataSnapshot.child("firstname").getValue().toString();
                      String lastname=dataSnapshot.child("lastname").getValue().toString();
                      String address=dataSnapshot.child("address").getValue().toString();

                      Picasso.get().load(image).into(profileImageView);
                      firstNameEditText.setText(firstname);
                      lastNameEditText.setText(lastname);
                      userphoneEditText.setText(phone);
                      addressEditText.setText(address);
                  }
              }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
